#!/bin/bash

java -Xmx128m -classpath classes:../../lib/jpct/jpct.jar HelloWorldSoftware

